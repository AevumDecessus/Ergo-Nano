G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4-10.0.4~ubuntu25.10.1*
G04 #@! TF.CreationDate,2026-11-27T20:56:45+00:00*
G04 #@! TF.ProjectId,switchplate,73776974-6368-4706-9c61-74652e6b6963,0.6.0*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4-10.0.4~ubuntu25.10.1) date 2026-11-27 20:56:45*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,3.300000*%
G04 APERTURE END LIST*
D10*
X59525000Y-58525000D03*
X154525000Y-58525000D03*
X59525000Y-115475000D03*
X171157272Y-152026083D03*
X154525000Y-96475000D03*
M02*
